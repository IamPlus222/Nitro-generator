Nitro brute force v4

V4 changelogs:
New: You can choose the bruteforce speed now!

that was it for this versions changelogs

The nitro bruteforcer might get you banned! Im not responsible for any of your actions, this tool was made for educational purposes.
Otherwise, have fun!